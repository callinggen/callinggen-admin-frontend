1:"$Sreact.fragment"
3:I[97367,["/_next/static/chunks/2w2n7gv-61s1q.js","/_next/static/chunks/0lskps5kqnsk2.js","/_next/static/chunks/1-8s9_t85wwr4.js","/_next/static/chunks/3j568g3vwg3rg.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":["$L2",null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"GXopXBvMhOyX3RWB_zJcP"}
5:null
2:E{"digest":"NEXT_REDIRECT;replace;/dashboard;307;"}
