globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/GXopXBvMhOyX3RWB_zJcP/_buildManifest.js",
    "static/GXopXBvMhOyX3RWB_zJcP/_ssgManifest.js",
    "static/GXopXBvMhOyX3RWB_zJcP/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/3k3xv6ye5so5r.js",
    "static/chunks/3rxl-jt3pdxgx.js",
    "static/chunks/2uc_jiuubq9v7.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/turbopack-1k-ny44zoovh6.js"
  ]
};
