globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/D4DL9Onm9SIi8VvoLwmWT/_buildManifest.js",
    "static/D4DL9Onm9SIi8VvoLwmWT/_ssgManifest.js",
    "static/D4DL9Onm9SIi8VvoLwmWT/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/3k3xv6ye5so5r.js",
    "static/chunks/3rxl-jt3pdxgx.js",
    "static/chunks/2uc_jiuubq9v7.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/turbopack-1k-ny44zoovh6.js"
  ]
};
